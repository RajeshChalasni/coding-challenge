package com.codingchallenge.vo;

import java.util.List;

public class EnrollVO extends BaseVO {

	private String phoneNumber;

	private List<DependentVO> dependents;

	private boolean activationStatus;

	public boolean isActivationStatus() {
		return activationStatus;
	}

	public void setActivationStatus(boolean activationStatus) {
		this.activationStatus = activationStatus;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public List<DependentVO> getDependents() {
		return dependents;
	}

	public void setDependents(List<DependentVO> dependents) {
		this.dependents = dependents;
	}

}
