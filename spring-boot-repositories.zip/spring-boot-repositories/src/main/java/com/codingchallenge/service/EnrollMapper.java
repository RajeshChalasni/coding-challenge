package com.codingchallenge.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.codingchallenge.model.Dependent;
import com.codingchallenge.model.Enroll;
import com.codingchallenge.vo.DependentVO;
import com.codingchallenge.vo.EnrollVO;

public class EnrollMapper {

	public static Enroll mapToEntity(EnrollVO vo) {
		Enroll enroll = new Enroll();

		if (vo != null) {

			enroll.setName(vo.getName());
			enroll.setBirthDate(convertToDate(vo.getBirthDate()));
			enroll.setPhoneNumber(vo.getPhoneNumber());
			enroll.setActivationStatus(true);

			List<DependentVO> dependents = vo.getDependents();
			List<Dependent> dependentList = new ArrayList<>();

			if (dependents != null && !dependents.isEmpty()) {
				dependents.stream().forEach(action -> {
					Dependent dependent = new Dependent();
					dependent.setName(action.getName());
					dependent.setBirthDate(convertToDate(action.getBirthDate()));
					dependent.setEnrollee(enroll);
					dependentList.add(dependent);
				});

				enroll.setDependents(dependentList);

			}
		}

		return enroll;
	}

	static Date convertToDate(String date) {
		if (date != null) {
			try {
				return new SimpleDateFormat("dd-MM-yyyy").parse(date);
			} catch (ParseException e) {
				e.printStackTrace();
				return null;
			}
		} else {
			return null;
		}
	}

	public static String convertDateToString(Date date) {
		if (date != null) {
			return new SimpleDateFormat("dd-MM-yyyy").format(date);
		} else {
			return null;
		}
	}

	public static EnrollVO mapToVO(Enroll entity) {
		EnrollVO enroll = new EnrollVO();

		if (entity != null) {

			enroll.setName(entity.getName());
			enroll.setBirthDate(convertDateToString(entity.getBirthDate()));
			enroll.setPhoneNumber(entity.getPhoneNumber());
			enroll.setId(entity.getId());
			enroll.setActivationStatus(entity.isActivationStatus());

			List<Dependent> dependents = entity.getDependents();
			List<DependentVO> dependentList = new ArrayList<>();

			if (dependents != null && !dependents.isEmpty()) {
				dependents.stream().forEach(action -> {
					DependentVO dependent = new DependentVO();
					dependent.setName(action.getName());
					dependent.setId(action.getId());
					dependent.setBirthDate(convertDateToString(action.getBirthDate()));
					dependentList.add(dependent);
				});

				enroll.setDependents(dependentList);

			}
		}

		return enroll;
	}

	public static List<EnrollVO> mapToVOList(List<Enroll> entityList) {
		if (entityList != null && !entityList.isEmpty()) {
			List<EnrollVO> list = new ArrayList<>();

			entityList.stream().forEach(entity -> {
				list.add(mapToVO(entity));
			});
			return list;
		}
		return new ArrayList<>();

	}

	public static Enroll mapToEntity(EnrollVO vo, Enroll enroll) {

		if (vo != null) {

			enroll.setName(vo.getName());
			enroll.setBirthDate(convertToDate(vo.getBirthDate()));
			enroll.setPhoneNumber(vo.getPhoneNumber());
			enroll.setActivationStatus(true);

			List<DependentVO> dependents = vo.getDependents();

			List<Dependent> dependentsEntityList = enroll.getDependents();

			List<Dependent> removeList = new ArrayList<>();

			if (dependents != null && !dependents.isEmpty()) {

				List<DependentVO> collect = dependents.stream().filter(d1 -> d1.getId() != null && d1.getId() > 0)
						.collect(Collectors.toList());
				removeList = dependentsEntityList.stream().filter(
						obj -> !(collect.stream().filter(o -> obj.getId() == o.getId()).findFirst().isPresent()))
						.collect(Collectors.toList());
				if (!dependentsEntityList.isEmpty() && !collect.isEmpty()) {
					dependentsEntityList.stream().map(action -> {
						collect.stream().forEach(d -> {
							// dependentsEntityList.removeIf(ac->!ac.getId().equals(d.getId()));
							if (action.getId().equals(d.getId())) {
								action.setId(action.getId());
								action.setName(d.getName());
								action.setBirthDate(convertToDate(d.getBirthDate()));
							}
						});

						return action;
					}).collect(Collectors.toList());
				}

				if (!removeList.isEmpty()) {

					for (Dependent dependent : removeList) {
						dependentsEntityList.remove(dependent);
					}

				}

				dependents.removeAll(collect);
				dependents.stream().forEach(d -> {
					if (d.getId() == null) {
						Dependent dependent = new Dependent();
						dependent.setName(d.getName());
						dependent.setBirthDate(convertToDate(d.getBirthDate()));
						dependent.setEnrollee(enroll);
						dependentsEntityList.add(dependent);
					}
				});
				enroll.setDependents(dependentsEntityList);

			}
		}

		return enroll;
	}

}
