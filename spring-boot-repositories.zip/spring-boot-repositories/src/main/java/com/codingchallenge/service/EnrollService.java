package com.codingchallenge.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingchallenge.dao.EnrollRepository;
import com.codingchallenge.model.Enroll;
import com.codingchallenge.vo.EnrollVO;

@Service
public class EnrollService implements IEnrollService {

	@Autowired
	private final EnrollRepository enrollRepository;

	public EnrollService(EnrollRepository enrollRepository) {
		this.enrollRepository = enrollRepository;
	}

	@Override
	public List<EnrollVO> getAllEnrollees() {
		return EnrollMapper.mapToVOList((List<Enroll>) enrollRepository.findAll());
	}

	@Override
	public EnrollVO getEnrolleeByID(Long enrollID) throws Exception {
		Optional<Enroll> findById = enrollRepository.findById(enrollID);

		if (findById.isPresent()) {
			return EnrollMapper.mapToVO(findById.get());

		} else {
			throw new Exception("Enroll details not found");
		}
	}

	@Override
	public EnrollVO create(EnrollVO enrollVO) throws Exception {

		Enroll mapToEntity = EnrollMapper.mapToEntity(enrollVO);
		if (enrollVO.getId() != null) {
			Optional<Enroll> findById = enrollRepository.findById(enrollVO.getId());
			if (findById.isPresent()) {
				throw new Exception("Enroll id already exist");
			}
		}
		Enroll enroll = enrollRepository.save(mapToEntity);

		enrollVO.setId(enroll.getId());
		return enrollVO;
	}

	@Override
	public EnrollVO update(EnrollVO enrollVO) throws Exception {

		Optional<Enroll> findById = enrollRepository.findById(enrollVO.getId());
		if (!findById.isPresent()) {
			throw new Exception("Enroll id not exist");
		}

		Enroll enroll = findById.get();
		Enroll mapToEntity = EnrollMapper.mapToEntity(enrollVO, enroll);

		enroll = enrollRepository.save(mapToEntity);
		enrollVO = EnrollMapper.mapToVO(enroll);

		return enrollVO;

	}

	@Override
	public void delete(Long enrolleeId) {
		enrollRepository.deleteById(enrolleeId);

	}

}
