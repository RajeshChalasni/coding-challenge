package com.codingchallenge.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.codingchallenge.vo.EnrollVO;

@Service
public interface IEnrollService {

	List<EnrollVO> getAllEnrollees();

	EnrollVO getEnrolleeByID(Long enrollID) throws Exception;

	EnrollVO create(EnrollVO enrollVO) throws Exception;

	EnrollVO update(EnrollVO enrollVO) throws Exception;

	void delete(Long enrolleeId) throws Exception;

}
