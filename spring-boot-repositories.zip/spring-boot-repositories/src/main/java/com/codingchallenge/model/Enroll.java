package com.codingchallenge.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;

@Entity
public class Enroll {

	@Id
	@GeneratedValue
	private Long id;

	@Column(length = 100)
	@NotEmpty
	private String name;

	private String phoneNumber;

	@Column
	private Date birthDate;

	@Column
	private boolean activationStatus;

	@OneToMany(mappedBy = "enrollee", cascade = CascadeType.ALL, orphanRemoval = true)
	List<Dependent> dependents = new ArrayList<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public boolean isActivationStatus() {
		return activationStatus;
	}

	public void setActivationStatus(boolean activationStatus) {
		this.activationStatus = activationStatus;
	}

	public List<Dependent> getDependents() {
		return dependents;
	}

	public void setDependents(List<Dependent> dependents) {
		this.dependents = dependents;
	}

	@Override
	public String toString() {
		return "PatientEnroll{" + "id=" + id + ", name='" + name + '\'' + ", birthDate=" + birthDate
				+ ", activationStatus=" + activationStatus + ", dependents=" + dependents + '}';
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}
