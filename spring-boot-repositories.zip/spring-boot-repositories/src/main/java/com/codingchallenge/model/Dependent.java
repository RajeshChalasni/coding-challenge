package com.codingchallenge.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotEmpty;

@Entity
public class Dependent {
	@Id
	@GeneratedValue
	private Long id;

	@Column(length = 100)
	@NotEmpty
	private String name;

	@Column
	private Date birthDate;

	@ManyToOne(optional = false)
	private Enroll enrollee;

	public Dependent() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public Enroll getEnrollee() {
		return enrollee;
	}

	public void setEnrollee(Enroll enrollee) {
		this.enrollee = enrollee;
	}

	/*
	 * @Override public boolean equals(Object obj) { if(this == obj) return true;
	 * if(obj == null || getClass() != obj.getClass()) return false; Dependent other
	 * = (Dependent) obj; if(id == null) { if(other.id !=null) { return false; }
	 * }else if(name == null) { if(other.name != null) { return false; } } return
	 * true; }
	 * 
	 * @Override public int hashCode() { int prime =31; int result =1; result= prime
	 * * result +((id == null)?0: id.hashCode()); result = prime * result +((name ==
	 * null) ?0: name.hashCode()); return result; }
	 * 
	 */
}
