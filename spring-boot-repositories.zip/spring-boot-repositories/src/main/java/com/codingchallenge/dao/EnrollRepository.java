package com.codingchallenge.dao;

import org.springframework.data.repository.CrudRepository;

import com.codingchallenge.model.Enroll;

public interface EnrollRepository extends CrudRepository<Enroll,Long> {

	/*
	 * @Query(value =
	 * "SELECT i FROM Item i left join Review r on i.id=r.item.id where avg(r.rating) < ?1"
	 * ) List<Patient> findItemsWithAverageRatingLowerThan(Double rating);
	 */
}
