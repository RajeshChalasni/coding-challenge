package com.codingchallenge.dao;

import org.springframework.data.repository.CrudRepository;

import com.codingchallenge.model.Dependent;

public interface UserRepository extends CrudRepository<Dependent, Long> {
}
